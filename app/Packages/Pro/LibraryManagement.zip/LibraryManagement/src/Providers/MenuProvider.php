<?php

namespace App\Packages\Pro\LibraryManagement\Providers;

use Illuminate\Support\Facades\Auth;

class MenuProvider
{
    public static function getMenuItems(): array
    {
        if (!Auth::check()) {
            return [];
        }

        $items = [];

        if (Auth::user()->can('view_library-management')) {
            $items[] = [
                'label' => 'Library',
                'icon'  => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z"/></svg>',
                'active' => request()->is('library*'),
                'permission' => 'view_library-management',
                'submenu' => [
                    [
                        'label'  => 'Books',
                        'route'  => 'library.books.index',
                        'active' => request()->routeIs('library.books.*'),
                    ],
                    [
                        'label'  => 'Members',
                        'route'  => 'library.members.index',
                        'active' => request()->routeIs('library.members.*'),
                    ],
                    [
                        'label'  => 'Issues',
                        'route'  => 'library.issues.index',
                        'active' => request()->routeIs('library.issues.*'),
                    ],
                    [
                        'label'  => 'Fines',
                        'route'  => 'library.fines.index',
                        'active' => request()->routeIs('library.fines.*'),
                    ],
                ],
            ];
        }

        return $items;
    }
}
