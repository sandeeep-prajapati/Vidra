<?php

namespace App\Packages\Pro\TestBundle\Controllers;

use Illuminate\Routing\Controller as BaseController;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;

class DashboardController extends BaseController
{
    public function index(): View
    {
        $data = [
            'bundleName' => 'Test Bundle',
            'version' => '1.0.0',
            'status' => 'Active',
        ];

        return view('test-bundle::dashboard', $data);
    }
}
