<div>
    <h1>{{ $bundleName }} v{{ $version }}</h1>
    <p>Status: {{ $status }}</p>
</div>
