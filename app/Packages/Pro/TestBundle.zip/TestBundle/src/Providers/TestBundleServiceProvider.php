<?php

namespace App\Packages\Pro\TestBundle\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class TestBundleServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->loadViewsFrom(
            __DIR__ . '/../Resources/views',
            'test-bundle'
        );

        $this->registerRoutes();
    }

    private function registerRoutes(): void
    {
        Route::middleware(['web'])
            ->prefix('test-bundle')
            ->name('test-bundle.')
            ->group(function () {
                require __DIR__ . '/../Routes/web.php';
            });
    }
}
